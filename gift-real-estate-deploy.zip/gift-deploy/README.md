# GIFT Real Estate — cPanel Deployment Guide

## Folder Structure

```
gift-real-estate/          ← upload this entire folder to your cPanel
├── index.mjs              ← Node.js app entry point (set as "Application startup file")
├── pino-*.mjs             ← logging workers (required)
├── thread-stream-worker.mjs
├── public/                ← static frontend files (served automatically)
│   ├── index.html
│   ├── assets/
│   ├── logo.png
│   └── ...
├── uploads/               ← image uploads (keep this folder, must be writable)
└── .env.example           ← rename to .env and fill in your values
```

## Setup Steps

### 1. Upload
Extract this zip into a directory on your server, e.g.:
`/home/YOUR_USERNAME/gift-real-estate/`

### 2. Set Environment Variables
In cPanel → Node.js App → Environment Variables, set:

| Variable | Value |
|---|---|
| `NEON_DATABASE_URL` | Your Neon PostgreSQL connection string |
| `SESSION_SECRET` | A long random secret string |
| `NODE_ENV` | `production` |

### 3. Configure the Node.js App in cPanel
- **Node.js version**: 20.x or higher
- **Application root**: path to this folder (e.g. `gift-real-estate`)
- **Application URL**: your domain or subdomain
- **Application startup file**: `index.mjs`

### 4. Make `uploads/` Writable
```bash
chmod 755 uploads/
```

### 5. Start the App
Click "Run NPM Install" (not needed — no node_modules required), then **Restart** the app.

## Admin Panel
Visit `https://yourdomain.com/admin` to log in.
Default credentials are set in the database — use the seed script if starting fresh.

## Notes
- All contact info (phone, address, email) is managed from the Admin → Settings page — no hardcoded values.
- Images uploaded via admin are stored in the `uploads/` folder.
- The `NEON_DATABASE_URL` must be accessible from your cPanel server's IP.
